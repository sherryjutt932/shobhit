const sen1 = "we are here to deliver";
const sen2 = "biggest brand’s of motorsports";

const ArrayData = [
    sen1,sen2,
    sen1,sen2,
    sen1,sen2,
    sen1,sen2,
];

export default ArrayData;
